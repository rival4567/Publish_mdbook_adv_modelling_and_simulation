'''
ann_xor
========
This script allows to train artificial neural network to solve problems
including XOR. This solution is very generalised as multiple hidden
layers could be used to solve other problems as well.

******************************************************
Author: Shivam Shivam (shivam0.mechatronics@gmail.com)
******************************************************
University: Technische Hochschule Deggendorf
--------------------------------------------
'''

# importing the required module
import matplotlib.pyplot as plt
import numpy as np

class NeuronLayer():
    '''
    This class creates a neuron layer for Artificial neural network.
    It returns random weights and random biases for the layer.

    :param num_inputs: Number of inputs of a neuron layer
    :type num_inputs: int

    :param num_neurons: Number of neuron connections to the layer
    :type num_neurons: int

    '''
    #pylint: disable=too-few-public-methods
    def __init__(self, num_inputs, num_neurons):
        '''Constructor Method'''
        # Random variables for weights and bias for the layer
        self.weights = np.random.uniform(size=(num_inputs, num_neurons))
        self.bias = np.random.uniform(size=(1, num_neurons))


class ArtificialNeuralNetwork():
    '''
    This class is used to train a neural network of multiple layers.
    If the neural network consists of only two inputs, it can plot a
    graph showing the boundaries.

    :param layers: A neural network of minimum two layers
    :type layers: list

    :TODO: Try adding changing learning rate to reduce oscillations
    '''

    def __init__(self, layers):
        '''Constructor Method'''
        self.layer = layers
        self.num_layer = len(layers)
        self.layer_output_list = []
        self.learning_rate = 0.2
        self.losses = []

    def sigmoid_activation(self, value):
        '''
        The sigmoid activation function.

        :param value: Sigmoid function is implemented on this.
        :type value: `array` or `list` of floats
        :return: Value of sigmoid function
        :rtype: `array or `list` of floats
        '''
        return 1 / (1 + np.exp(-value))


    def linear_activation(self, value, index):
        '''
        Linear Activation function. weights * `value` + bias

        :param value: Linear Activation function is implemented on this.
        :type value: `array` or `list` of floats
        :param index: It gives the layers number from which weights and bias
                    are extracted
        :type index: int
        :return: Output of linear activation function
        :rtype: `array` or `list` of floats
        '''

        return np.dot(value, self.layer[index].weights) + self.layer[index].bias


    def sigmoid_derivative(self, value):
        '''
        The first derivative of the sigmoid function wrt `value`.

        :param value: Sigmoid Derivative is implemented on this.
        :type value: `array` or `list` of floats
        :return: Output of sigmoid derivative
        :rtype: `array` or `list` of floats
        '''
        return value * (1 - value)


    def forward_feeding(self, input_set):
        '''
        Feed Forward function for learning of neural network. This algorithm
        takes updates each layer based on previous layer output by using
        ``sigmoid_activation()`` and ``linear_activation()`` methods.

        :param input_set: Training set input for the training of network
        :type input_set: `array` or `list` of floats, ints
        :return: Final layer output
        :rtype: `array` or `list` of floats
        '''
        self.layer_output_list = []
        for lay in range(self.num_layer):
            layer_output = input_set if lay == 0 \
                else self.layer_output_list[lay-1]

            self.layer_output_list.append(self.sigmoid_activation(
                            self.linear_activation(layer_output, lay)))

        return self.layer_output_list[-1]


    def back_propagation(self, output, desired_output):
        '''
        This method calculates the gradient required to update the
        weights of each layer based on back propagation algorithm.
        It also calculates the losses in desired output and
        calculated output using ``forward_feeding()`` method.

        :param output: Calcuated output using ``forward_feeding()``
                    method
        :type output: `array` or `list` of floats
        :param desired_output: Target output
        :type desired_output: `array` or `list` of floats, ints
        :return: gradient required to update the weights of each layer
        :rtype: `array` or `list` of floats
        '''
        # Calculate losses
        loss = 0.5 * (desired_output - output) ** 2
        self.losses.append(np.sum(loss))

        # Final delta, we are moving from back to first
        error = (desired_output - output)
        delta = (error * self.sigmoid_derivative(output))
        delta_list = [delta]

        # Calcuate delta for each layer backwards
        for lay in range(self.num_layer - 1):
            hidden_delta = np.dot(
                delta_list[lay], (self.layer[-(lay+1)].weights.T)) \
            * self.sigmoid_derivative(self.layer_output_list[-(lay+2)])
            delta_list.append(hidden_delta)

        # Reverse and return the list
        return delta_list[::-1]


    def train(self, num_iterations, training_set_inputs, training_set_outputs):
        '''
        This method trains the neural network for a specific task. It
        then updates the weights and biases based on
        ``back_propagation()`` method.

        :param num_iterations: provides the number of interations on
                    which to train the neural network
        :type num_iterations: int
        :param training_set_inputs: On which to train the ANN
        :type training_set_inputs: `array` or `list` of floats, ints
        :param training_set_outputs: On which to train the ANN
        :type training_set_outputs: `array` or `list` of floats, ints
        '''
        for iteration in range(num_iterations):
            trained_output = self.forward_feeding(training_set_inputs)
            delta = self.back_propagation(
                trained_output, training_set_outputs)

            for lay in range(self.num_layer):
                grad = training_set_inputs.T @ delta[lay] if lay == 0 else \
                    self.layer_output_list[lay-1].T @ delta[lay]
                self.layer[lay].weights += (self.learning_rate * grad)
                self.layer[lay].bias += np.sum(
                    self.learning_rate * delta[lay], axis=0)

            print(iteration + 1, trained_output)



    def classify(self, input_set):
        '''
        Return the class to which a datapoint belongs based on
        the ANN output for that point.

        :param input_set: datapoints for classifications
        :type input_set: list of [x, y]
        :return: `1` if trained_output > 0.5, otherwise `0`
        :rtype: int
        '''
        if self.forward_feeding(input_set) > 0.5:
            return 1
        return 0


    def plot_2d(self, input_list, output_list, hmin=0.01):
        '''
        Generate plot of input data and decision boundary.

        :param input_list: Training set input for plotting
        :type input_list: `array` or `list` of floats, ints
        :param output_list: Training set output for plotting
        :type output_list: `array` or `list` of floats, ints
        '''
        # setting plot properties like size, theme and axis limits
        plt.figure(figsize=(5, 5))
        plt.axis('scaled')
        plt.xlim(-0.1, 1.1)
        plt.ylim(-0.1, 1.1)
        plt.xlabel('x - axis')
        plt.ylabel('y - axis')

        colors = {
            0: "red",
            1: "green"
        }

        # Plot the datapoints and their color based on ``output_list``
        for iteration, value in enumerate(input_list):
            plt.plot(value[0], value[1], color='black',linestyle='-',
                marker='o', markerfacecolor=colors[
                    output_list[iteration][0]], markersize=15)

        # Color the graph based on after training
        x_range = np.arange(-0.1, 1.1, hmin)
        y_range = np.arange(-0.1, 1.1, hmin)

        # creating a mesh to plot decision boundary
        x_mesh, y_mesh = np.meshgrid(x_range, y_range, indexing='ij')
        classify = np.array([[
            self.classify([x, y]) for x in x_range] for y in y_range])

        # using the contourf function to create the plot
        plt.contourf(x_mesh, y_mesh, classify, colors=[
            'red', 'green', 'green', 'blue'], alpha=0.4)


    def print_weights(self):
        '''The neural network prints its weights'''
        print("\nNumber of layers: ", self.num_layer)
        layer_number = 0
        for lay in self.layer:
            layer_number += 1
            print("\nLayer: ", layer_number, lay.weights)


def main():
    '''Main Function. It trains the XOR Function using
    ``ArtificialNeuralNetwork()`` class and then plots the boundary
    graph.'''
    input_list = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    output_list = np.array([[0, 1, 1, 0]]).T

    layer = []
    # Create layer 1 (2 inputs, 2 neurons)
    layer.append(NeuronLayer(2, 2)) # Hidden layer
    # layer.append(NeuronLayer(2, 5))
    #layer.append(NeuronLayer(5, 6))
    # Create layer 2 (2 inputs, 1 output)
    layer.append(NeuronLayer(2, 1)) # Output layer

    ann = ArtificialNeuralNetwork(layer)

    print("\nStage 1) Before Training (weights): ")
    ann.print_weights()

    # Increase the number of iterations when using multiple hidden layers
    ann.train(8000, input_list, output_list)

    print("\nStage 2) After Training (weights): ")
    ann.print_weights()

    print("\nStage 3) Testing: [1, 1]")
    trained_output = ann.forward_feeding([[1, 1]])
    print(trained_output)

    # Plot losses graph
    plt.title('LOSSES')
    plt.plot(ann.losses)

    # If number of inputs is equal to 2, plot the 2d graph
    if len(input_list[0]) == 2:
        ann.plot_2d(input_list, output_list)
        plt.title('XOR Function')

    plt.show()

if __name__ == "__main__":
    main()
